package com.example.capstone;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.material.bottomnavigation.BottomNavigationView;


public class MainActivity extends AppCompatActivity {
    AnimationDrawable awakeAnimation;
    private static final long START_TIME_IN_MILLIS = 5000;
    private CountDownTimer mCountDownTimer;
    private boolean mEatTimerRunning;
    private long mTimeLeftInMillis = START_TIME_IN_MILLIS;
    private Handler handler = new Handler();
    private final int interval = 50000; // 3s until food decays
    private final int interval2 = 10000; // 6s until poop spawns
    private Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button foodButton = findViewById(R.id.food_button);
        final Button wasteButton = findViewById(R.id.waste_button);

        ImageView imageView = findViewById(R.id.imageView);//keep
        imageView.setBackgroundResource(R.drawable.animationdog);//keep
        AnimationDrawable AniDog = (AnimationDrawable) imageView.getBackground();//keep
        AniDog.start();//keep



        wasteButton.setVisibility(View.INVISIBLE);
        foodButton.setBackground(getResources().getDrawable(R.drawable.food1));

        foodButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                foodButton.setBackground(getResources().getDrawable(R.drawable.food2));
                handler.postDelayed(runnable, interval);
            }

        });
        wasteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                wasteButton.setVisibility(View.INVISIBLE);
                handler.postDelayed(runnable, interval2);
            }

        });

        runnable = new Runnable(){
            public void run() {
                foodButton.setBackground(getResources().getDrawable(R.drawable.food1));
                wasteButton.setVisibility(View.VISIBLE);
            }
        };




        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                    new ToyBoneFragment()).commit();
        }
    }
    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    Fragment selectedFragment = null;

                    switch (menuItem.getItemId()) {
                        case R.id.nav_toybone:
                            selectedFragment = new ToyBoneFragment();
                            break;
                        case R.id.nav_treat:
                            selectedFragment = new TreatFragment();
                            break;

                        case R.id.nav_toy:
                            selectedFragment = new ToyFragment();
                            break;

                    }

                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,selectedFragment).commit();
                    return true;

                }





    };
}
