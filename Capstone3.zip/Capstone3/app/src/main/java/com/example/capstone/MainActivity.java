package com.example.capstone;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


public class MainActivity extends AppCompatActivity {
    private static final long START_TIME_IN_MILLIS = 5000;
    private CountDownTimer mCountDownTimer;
    private boolean mEatTimerRunning;
    private long mTimeLeftInMillis = START_TIME_IN_MILLIS;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button foodButton = findViewById(R.id.food_button);

        ImageView imageView = findViewById(R.id.imageView);//keep
        imageView.setBackgroundResource(R.drawable.animationdog);//keep
        AnimationDrawable AniDog = (AnimationDrawable) imageView.getBackground();//keep
        AniDog.start();//keep

        foodButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mEatTimerRunning) {
                    bowlFull();
                } else {
                    refillBowl();
                }

            }


            private void bowlFull() {
                mCountDownTimer = new CountDownTimer(mTimeLeftInMillis, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        mTimeLeftInMillis = millisUntilFinished;
                    }

                    @Override
                    public void onFinish() { //when bowl is finished, set image to food1
                        mEatTimerRunning = false;
                        foodButton.setBackgroundResource(R.drawable.food1);


                    }
                }.start();
                mEatTimerRunning = true;

            }

            private void refillBowl() { //when bowl is clicked, set image to food2

                mTimeLeftInMillis = START_TIME_IN_MILLIS;
                foodButton.setBackgroundResource(R.drawable.food2);


            }

        });

    }
}
